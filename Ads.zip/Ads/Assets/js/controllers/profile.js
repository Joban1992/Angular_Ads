angular.module('app.controllers').controller('profileCntrl', function($scope, $timeout){
  console.log('profile ctrl');
  $scope.init = function(){
  }
  $scope.init();
})