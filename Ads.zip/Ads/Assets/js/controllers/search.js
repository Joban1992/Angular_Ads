angular.module('app.controllers').controller('searchCntrl', function($scope, $timeout){
  console.log('search ctrl');
  //$timeout(function(){$scope.$parent.notiText = "Search Page"},0);
})